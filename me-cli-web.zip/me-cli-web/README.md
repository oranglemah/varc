# MYnyak Engsel Web (Next.js 14 App Router)

## Quickstart
```bash
npm i
cp .env.example .env.local
npm run dev
```

## Deploy (Vercel)
- Push repo ke GitHub.
- Import di Vercel (Framework: Next.js, Root: repo root).
- Tambah Environment Variables dari `.env.example` ke Project Settings (Preview & Production).
- Redeploy.
